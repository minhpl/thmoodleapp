<?php

$string['pluginname'] = 'Moodle App Behat (auto-generated)';
$string['privacy_metadata'] = 'This plugin should only be used in development environments, and it does not store any user data.';
